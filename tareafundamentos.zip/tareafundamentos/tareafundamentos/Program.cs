﻿using System;

namespace tareafundamentos
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] archivolineas = System.IO.File.ReadAllLines(@"C:\Users\Dell\source\repos\separar en clases la desviacion\separar en clases la desviacion\bin\Debug\librocaca.txt");


            string laLinea = archivolineas[0];

            

            string[] datos = laLinea.Split(','); //aqui en la variable datos tengo todos los datos de la linea que acabo de leer
            int segundo = 0;
            int primero = 0;
            int tercero = 0;

            for (int i = 2; i < datos.Length; i++)
            {
                int x = int.Parse(datos[i]);
             
                Console.WriteLine("introduce un numero");
                while (x != 0)
                {

                    if (x > primero)
                    {
                        tercero = segundo;
                        segundo = primero;
                        primero = x;
                    }
                    else
                    {
                        if (x > segundo)
                        {
                            tercero = segundo;
                            segundo = x;
                        }
                        else
                        {
                            if (x > tercero)
                            {
                                tercero = x;
                            }
                        }
                    }

                }
            }
            Console.WriteLine("{0}, {1}, {2}", primero, segundo, tercero);
            
        }
    }
}
